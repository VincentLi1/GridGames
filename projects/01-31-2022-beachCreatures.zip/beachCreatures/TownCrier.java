import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import java.util.*;
import info.gridworld.grid.Location;
import info.gridworld.grid.Grid;

/**
 * `TownCrier` extends `Critter` and thrives off attention. 
 * It looks at all neighbors within 2 tiles away and counts 
 * the number of `Critters`. If that number is greater than 
 * some threshold @param t , it will turn green. Otherwise, it will
 *  turn red. `t` is a parameter in the constructor. _Hint:_ 
 * use its `Location` to find all Critters in its range. Use 
 * `instanceof` to check if an actor is a `Critter`.
 */

public class TownCrier extends Critter {
    
    public int t;

    // Construct a TownCrier with a given threshold.
    public TownCrier(int threshold){
        t = threshold;
    }

 /** getLocationsInDirections() and the corresponding comment is copied from the CrabCritter code.
     * Finds the valid adjacent locations of this critter in different
     * directions.
     * @param directions - an array of directions (which are relative to the
     * current direction)
     * @return a set of valid locations that are neighbors of the current
     * location in the given directions
     */
    public ArrayList<Location> getLocationsInDirections(int[] directions)
    {
        ArrayList<Location> locs = new ArrayList<Location>();
        Grid<Actor> gr = getGrid();
        Location loc = getLocation();
    
        for (int d : directions)
        {
            Location neighborLoc = loc.getAdjacentLocation(getDirection() + d);
            if (gr.isValid(neighborLoc))
                locs.add(neighborLoc);
        }
        return locs;
    }    

    // It looks at all neighbors within 2 tiles away; we must override getActors().
    // @Override
    // public ArrayList<Actor> getActors() {
    //     int numCritters = 0;
        
    //     int[] nums = {-2,-1,0,1,2};
    //     for (int x : nums){
    //         for (int y : nums){
    //             //Location newLoc = getLocation() + (x,y); // we need to add in the x and y. Not sure how to do it, though. 
    //         }
    //     }
    //     // Finish the last 4 classes by next Friday. The last 2 will be graded.

    //     // int[] directions = 
    //     //     {Location.EAST,Location.NORTH,Location.SOUTH,Location.WEST,
    //     //     Location.NORTHEAST,Location.NORTHWEST,Location.SOUTHEAST,Location.SOUTHWEST};
    //     ArrayList<Actor> actors = new ArrayList<Actor>();

    //     // The problem is that it only looks at the adjacent tiles. We might do a grid of -2,...,2 for x and y to ensure that everything is covered (taking care to subtract the TownCrier itself).
    //     for (Location loc : getLocationsInDirections(directions)){
            
    //         // If there is a Critter in the given location, then keep track of that using numCritters.
    //         if (!getGrid().get(loc).equals(null)){
    //             numCritters ++;
    //         }
    //     }


    //     getGrid().getNeighbors(getLocation()); // The actors that are neighboring the current actor

    //     return;
    // } 

}
